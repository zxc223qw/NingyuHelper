package com.example.ningyuhelper

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "宁屿挂机助手 · 独立原型"
            textSize = 22f
        })
        layout.addView(TextView(this).apply {
            text = "第一阶段：用户自设坐标点击宏。尚未包含怪物识别、自动拾取判断或自动补血逻辑。"
            textSize = 14f
            setPadding(0, 12, 0, 18)
        })
        xInput = field("点击 X（屏幕宽度百分比 0–100）", "90")
        yInput = field("点击 Y（屏幕高度百分比 0–100）", "58")
        intervalInput = field("点击间隔（毫秒，至少 800）", "1800")
        layout.addView(xInput)
        layout.addView(yInput)
        layout.addView(intervalInput)

        val permission = Button(this).apply {
            text = "打开无障碍服务设置"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(permission)

        val overlay = Button(this).apply {
            text = "申请悬浮窗权限"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else status.text = "悬浮窗权限已允许"
            }
        }
        layout.addView(overlay)

        val save = Button(this).apply {
            text = "保存点击参数"
            setOnClickListener {
                val x = xInput.text.toString().toFloatOrNull()
                val y = yInput.text.toString().toFloatOrNull()
                val ms = intervalInput.text.toString().toLongOrNull()
                if (x == null || y == null || ms == null || x !in 0f..100f ||
                    y !in 0f..100f || ms < 800) {
                    status.text = "参数无效：X/Y 为 0–100，间隔不能低于 800 毫秒"
                } else {
                    getSharedPreferences("macro", MODE_PRIVATE).edit()
                        .putFloat("x", x).putFloat("y", y).putLong("ms", ms).apply()
                    status.text = "参数已保存。请开启本应用无障碍服务，再回到游戏使用悬浮控制。"
                }
            }
        }
        layout.addView(save)
        status = TextView(this).apply {
            text = "状态：未启动"
            textSize = 15f
            setPadding(0, 18, 0, 0)
        }
        layout.addView(status)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun field(label: String, value: String): EditText {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(TextView(this).apply { text = label })
        val edit = EditText(this).apply {
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        wrap.addView(edit)
        // Returned field is used for data; view is added to activity in onCreate.
        return edit
    }
}
