package com.example.ningyuhelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.view.accessibility.AccessibilityEvent

class GameAutomationService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var panel: LinearLayout? = null
    private lateinit var wm: WindowManager
    private val task = object : Runnable {
        override fun run() {
            if (!running) return
            performConfiguredTap()
            val ms = getSharedPreferences("macro", MODE_PRIVATE).getLong("ms", 1800L)
            handler.postDelayed(this, ms.coerceAtLeast(800L))
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xDD20242A.toInt())
        }
        val start = Button(this).apply {
            text = "开始点击"
            setOnClickListener {
                if (!running) {
                    running = true
                    handler.post(task)
                    text = "运行中（点此暂停）"
                } else {
                    running = false
                    handler.removeCallbacks(task)
                    text = "开始点击"
                }
            }
        }
        val stop = Button(this).apply {
            text = "停止并关闭面板"
            setOnClickListener {
                running = false
                handler.removeCallbacks(task)
                try { wm.removeView(box) } catch (_: Exception) {}
                panel = null
            }
        }
        box.addView(start)
        box.addView(stop)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 180 }
        wm.addView(box, params)
        panel = box
    }

    private fun performConfiguredTap() {
        val prefs = getSharedPreferences("macro", MODE_PRIVATE)
        val xPct = prefs.getFloat("x", 90f).coerceIn(0f, 100f)
        val yPct = prefs.getFloat("y", 58f).coerceIn(0f, 100f)
        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(dm.widthPixels * xPct / 100f, dm.heightPixels * yPct / 100f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 70))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {
        running = false
        handler.removeCallbacks(task)
    }
    override fun onDestroy() {
        running = false
        handler.removeCallbacks(task)
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
